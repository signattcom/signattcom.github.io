<?php
	require 'notification.php';
    header("Location: ./spectrum.html");
?>
